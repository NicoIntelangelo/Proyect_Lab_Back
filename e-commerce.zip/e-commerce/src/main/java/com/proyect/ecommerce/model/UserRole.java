package com.proyect.ecommerce.model;

public enum UserRole {
    USER,ADMIN,SUPER_ADMIN
}
