package com.proyect.ecommerce.service;

public enum AppUserRole {
    USER,ADMIN,SUPER_ADMIN
}
